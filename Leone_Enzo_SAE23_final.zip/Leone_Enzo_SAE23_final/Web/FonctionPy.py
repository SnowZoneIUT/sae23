import os,pymysql
from configDB import dbConnect,serveurConnect
from mkRequest import _requetes, mkInsert_Produit_Request, mkInsert_Lieu_Request, mkInsert_Prix_Request, mkDelete_Produit_Request, mkDelete_Prix_Request, mkGetAllbyPrice, mkGetProduitBy

def createBaseMySQL() -> None :
     _dbMontre, _cursorMontre = serveurConnect()
     _cursorMontre.execute(_requetes["drop"])
     _cursorMontre.execute(_requetes["createBase"])
     _cursorMontre.execute(_requetes["use"])
     _cursorMontre.execute(_requetes["createTable_lieux"])
     _cursorMontre.execute(_requetes["reset_increment_lieu"])
     _cursorMontre.execute(_requetes["createTable_produits"])
     _cursorMontre.execute(_requetes["reset_increment_produits"])
     _cursorMontre.execute(_requetes["createTable_dedans"])
     _cursorMontre.execute(_requetes["createTable_connexion"])
     _cursorMontre.execute(_requetes["createTable_prix_enchere"])
     executeReq(_requetes["contrainte"])
     executeReq(_requetes["contrainte2"])
     executeReq(_requetes["userdefault"])
  
def TryConnect():
	db,cursor = dbConnect()
	result = executeReq(_requetes["getAll"])
	return result
	
def initBase() -> None :
    """ Vérifie que la base existe, sinon propose de la créer en mode CLI.
            Jette une exception si paramètres de connexion incorrects """
    try :
        TryConnect()
    except pymysql.err.OperationalError as e:
        print(e)
        if '1044' in str(e) :
            print ("Vérifiez les paramètres de connexion")
            raise e
        elif '1049' in str(e) :
            choix = input("base inexistante, voulez-vouz créer une base 'montre' standard? (y/n) :")
            if choix not in 'yYOo' :
                raise e
            createBaseMySQL()

#def execute(req : str) :    # type de valeur rendu variable :-(
  #  _dbMontre, _cursorMontre = serveurConnect()
   # cur = _cursorMontre.execute(req)
   # res = _cursorMontre.fetchall()
   # _dbMontre.commit()
    #if "select" in req or "SELECT" in req or "montre" in res:
    #    res = _cursorMontre.fetchall()
    #else :
    #    _dbMontre.commit()
    #return res

def executeReq(req : str, boolean = True) -> tuple :
    _dbEtudiant, _cursorEtudiant = dbConnect()
    cr = _cursorEtudiant.execute(req)
    res = _cursorEtudiant.fetchall()
    _dbEtudiant.commit()
    if boolean :
        return res
    else :
        return cr,res

def createBase()-> None :
    """ Crée la base montre (uniquement MySQL actuellement) """
    executeReq("")
    pass

def reset() -> None :
    """ Remise à zéro de la table """
    req = _requetes["reset_dedans"]
    executeReq(req)
    req = _requetes["reset_prix_enchere"]
    executeReq(req)
    req = _requetes["reset_lieux"]
    executeReq(req)
    req = _requetes["reset_produits"]
    executeReq(req)
    req= _requetes["reset_connexion"]
    executeReq(req)
    executeReq(_requetes["createTable_lieux"])
    executeReq(_requetes["reset_increment_lieu"])
    executeReq(_requetes["createTable_produits"])
    executeReq(_requetes["reset_increment_produits"])
    executeReq(_requetes["createTable_dedans"])
    executeReq(_requetes["createTable_connexion"])
    executeReq(_requetes["createTable_prix_enchere"])
    executeReq(_requetes["contrainte"])
    executeReq(_requetes["contrainte2"])
    executeReq(_requetes["userdefault"])

def getProduits() -> list :
    """ getProduitss() -> liste de tuples "Produit"
    Rend le contenu de la base sous forme d'une liste de tuples """
    req = _requetes["getAll"]
    produits = []
    for t in executeReq(req) :
        produits.append(t)
    return produits

def getenchere():
    req = _requetes["get_prix_enchere"]
    enchere = []
    for t in executeReq(req) :
        enchere.append(t)
    return enchere

def getTable_User():
    req = _requetes["getTable_User"]
    users = []
    for t in executeReq(req):
        users.append(t)
    return users

def getTable_enchere():
    req = _requetes["getTable_enchere"]
    enchere = []
    for t in executeReq(req):
        enchere.append(t)
    return enchere


def insertPrix(parametres):
    produit=""
    lieu=""
    prix=""
    date=""
    if "produit" in parametres:
        produit=parametres["produit"]
    if "lieu" in parametres:
        lieu=parametres["lieu"]
    if "prix" in parametres:
        prix=parametres["prix"]
    if "date" in parametres:
        date=parametres["date"]
    req = _requetes["insert_prix"].format(produit, lieu, prix, date)
    executeReq(req)

def insertenchere(parametres):
    id_connexion=""
    id_produits=""
    prix_base=""
    prix_final=""
    if "id_connexion" in parametres:
        id_connexion=parametres["id_connexion"]
    if "id_produits" in parametres:
        id_produits=parametres["id_produits"]
        id_produits = int(id_produits)
    if "prix_base" in parametres:
        prix_base=parametres["prix_base"]
        prix_base = float(prix_base)
    if "prix_final" in parametres:
        prix_final=parametres["prix_final"]
        prix_final=float(prix_final)
    req = _requetes["insert_enchere"].format(id_connexion, id_produits, prix_base, prix_final)
    executeReq(req)


def insertProduit(parametres):
    nom=""
    description=""
    fabricant=""
    mouvement=""
    if "nom" in parametres:
        nom=parametres["nom"]
    if "description" in parametres:
        description=parametres["description"]
    if "fabricant" in parametres:
        fabricant=parametres["fabricant"]
    if "mouvement" in parametres:
        mouvement=parametres["mouvement"]
    req = _requetes["insert_produit"].format(nom, description, fabricant, mouvement, 0)
    executeReq(req)

def insertUser(parametres):
    mail =""
    nom =""
    prenom =""
    login =""
    mdp =""
    if "mail" in parametres:
        mail = parametres["mail"]
    if "nom" in parametres:
        nom = parametres["nom"]
    if "prenom" in parametres:
        prenom = parametres["prenom"]
    if "login" in parametres:
        login = parametres["login"]
    if "mdp" in parametres:
        mdp = parametres["mdp"]
    req = _requetes["create_user"].format(mail, nom, prenom, login, mdp, 0)
    executeReq(req)

def insertLieu(parametres):
    url=""
    if "url" in parametres:
        url =parametres["url"]
    req = _requetes["insert_lieux"].format(url)
    executeReq(req)

def updateAuction(parametres):
    produit=""
    enchere=0
    price_auction=""
    table = getTable_enchere()
    print(table)
    if "produit" in parametres:
        produit=parametres["produit"]
        produit=int(produit)
    for index in range (len(table)):
        if table[index][1] == produit:
            req=_requetes["delete_ligne_prix_enchere"].format(produit)
            executeReq(req)   
    if parametres["enchere"] == "on":
        enchere = 1
    if "price_auction" in parametres and enchere==1:
        price_auction=parametres["price_auction"]
        price_auction=float(price_auction)
        req=_requetes["prix_enchere"].format(produit, price_auction, price_auction)
        executeReq(req)
    req=_requetes["mettre_aux_encheres"].format(enchere, produit)
    executeReq(req)

def getPlusBasPrix(prix):
    req = _requetes["getAllByPrice"].format(prix)
    prix = []
    produit=''
    for t in executeReq(req):
        prix.append(t)
    for elem in prix:
        produit = produit + f"nom : {elem[0]}, url : {elem[1]}, prix : {elem[2]}" + "\n"
    return produit


def GetTableLieux():
    req = _requetes["getTable_lieux"]
    lieux = []
    for t in executeReq(req):
        lieux.append(t)
    return lieux

def GetTableProduit():
    req = _requetes["getTable_produits"]
    produits = []
    for t in executeReq(req):
        produits.append(t)
    return produits

def GetTablePrix():
    req = _requetes["getTable_prix"]
    prix = []
    for t in executeReq(req):
        prix.append(t)
    return prix

def DeletePrix(id_produit, id_lieu):
    req = mkDelete_Prix_Request(id_produit, id_lieu)
    executeReq(req)

def DeleteProd(parametres):
    id=""
    if "id" in parametres:
        id = parametres["id"]
    req = _requetes["delete_produit_by_id"].format(id)
    executeReq(req)

def dbToString() -> str :
    """ Rend le contenu de chaque table sous forme d'une chaîne de caractères """
    lieu= ''
    produit=''
    prix=''
    tout = ''
    for etud in GetTableLieux():
        lieu = lieu + f" id : {etud[0]}, url : {etud[1]}" + "\n"
    for etud in GetTableProduit():
        produit = produit + f" id : {etud[0]}, nom : {etud[1]}, description : {etud[2]},fabricant : {etud[3]}, mouvement : {etud[4]}, enchère : {etud[5]} " + "\n"
    for etud in GetTablePrix():
        prix = prix + f" id_produit : {etud[0]}, id_lieu : {etud[1]}, prix : {etud[2]}, date : {etud[3]}" + "\n"
    for etud in getProduits():
        tout = tout + f" nom du produit : {etud[1]}, url du lieu : {etud[2]}, prix : {etud[3]}, date : {etud[4]}" + "\n"
    return lieu, produit, prix, tout

def filters(parametres):
    db, cursor = dbConnect()
    prix=""
    query = ""
    producer_1=""
    type_quartz=""
    type_automatique=""
    type_manuel=""
    auction_yes=""
    auction_no=""
    if parametres == None or parametres["prix"] == '':
        query = "SELECT * FROM produits"
    else:
        if query == "":
            if parametres["prix"] !='':
                query = f"""select distinct p.* from produits p join dedans d on d.id_produit = p.id where d.prix< {parametres["prix"]} """
                if "type_quartz" in parametres:
                    query = query + """and p.mouvement = "quartz" """
                    if "type_automatique" in parametres:
                        query = query + """ or p.mouvement = "automatique" """
                    if "type_manuel" in parametres:
                        query = query + """ or p.mouvement = "manuel" """
                elif "type_automatique" in parametres:
                    query = query + """and p.mouvement = "automatique" """
                    if "type_manuel" in parametres:
                        query = query + """ or p.mouvement = "manuel" """
                elif "type_manuel" in parametres:
                    query = query + """ and p.mouvement = "manuel" """
            ##### les requetes pour les enchères
                if "auction_yes" in parametres:
                    query = query + """and enchere = "1" """
                    if "auction_no" in parametres:
                        query = query + """and enchere = "0" """
                elif "auction_no" in parametres:
                    query = query + """and enchere = "0" """
            elif "type_quartz" in parametres:
                query = query + """ SELECT * FROM produits where mouvement = "quartz" """
            elif "type_automatique" in parametres:
                query = query + """ SELECT * FROM produits where mouvement = "automatique" """
            elif "type_manuel" in parametres:
                query = query + """ SELECT * FROM produits where mouvement = "manuel" """
            elif "auction_yes" in parametres:
                query = query + """ SELECT * FROM produits where enchere = "1" """
            elif "auction_no" in parametres:
                query = query + """ SELECT * FROM produits where enchere = "0" """
        if query != "":
            #### les requetes pour les types
            if "type_quartz" in parametres:
                query = query + """and mouvement = "quartz" """
                if "type_automatique" in parametres:
                    query = query + """ or mouvement = "automatique" """
                if "type_manuel" in parametres:
                    query = query + """ or mouvement = "manuel" """
            elif "type_automatique" in parametres:
                query = query + """and mouvement = "automatique" """
                if "type_manuel" in parametres:
                    query = query + """ or mouvement = "manuel" """
            elif "type_manuel" in parametres:
                query = query + """ and mouvement = "manuel" """
            ##### les requetes pour les enchères
            if "auction_yes" in parametres:
                query = query + """and enchere = "1" """
                if "auction_no" in parametres:
                    query = query + """and enchere = "0" """
            elif "auction_no" in parametres:
                query = query + """and enchere = "0" """    
    cursor.execute(query)
    result = cursor.fetchall()
    retour = []
    for t in result:
        retour.append(t)
    return retour


#############################################################
##
##      CSV 
###########################################################
    

def dbToCSV():
    lieu=''
    produit=''
    prix=''
    user=''
    enchere=''
    for elem in GetTableLieux():
        lieu = lieu +"lieu;"+ f"{elem[1]}"+'\n' 
    for elem in GetTableProduit():
        produit = produit +"produit;"+ f"{elem[1]};{elem[2]};{elem[3]};{elem[4]};{elem[5]}"+'\n'
    for elem in GetTablePrix():
        prix = prix + "prix;"+f"{elem[0]};{elem[1]};{elem[2]};{elem[3]}"+'\n'
    for elem in getTable_User():
        if not(elem[0] == "root" or elem[0]=="mailtest"):
            user = user +"user;" + f"{elem[0]};{elem[1]};{elem[2]};{elem[3]};{elem[4]}"+'\n'
    for elem in getTable_enchere():
        enchere = enchere +"enchere;"+f"{elem[0]};{elem[1]};{elem[2]};{elem[3]}"+'\n'
    return lieu, produit, prix, user, enchere


def saveToTextFile(path="base.txt"):
    """ Permet d'exporter la table "etudiant" de la base dans un fichier texte "bien formatté" """
    with open(path,"w") as f :
        lieu, produit, prix, user, enchere = dbToCSV()
        f.write(lieu)
        f.write(produit)
        f.write(prix)
        f.write(user)
        f.write(enchere)

def loadFromCSVFile() -> None:
    """ Permet de charger une liste de données à partir d'un fichier texte "CSV" """
    import csv
    with open("base.txt", newline='\n',encoding='utf-8') as csvFile :
        lignesEtud = csv.reader(csvFile,delimiter=';')
        for champs in lignesEtud :
            if champs[0] == "lieu" :
                lieu={}
                lieu["url"] = champs[1]
                insertLieu(lieu)
            elif champs[0]=="produit":
                produit = {}
                produit["nom"] = champs[1]
                produit["description"] = champs[2].replace("'", "\\'")
                produit["fabricant"] = champs[3]
                produit["mouvement"] = champs[4]
                insertProduit(produit)
            elif champs[0]== "prix" :
                price={}
                price["produit"] = champs[1]
                price["lieu"] = champs[2]
                price["prix"] = champs[3]
                price["date"] = champs[4]
                insertPrix(price)
            elif champs[0]=="user":
                user={}
                user["mail"] =champs[1]
                user["nom"]=champs[2]
                user["prenom"]=champs[3]
                user["login"]=champs[4]
                user["mdp"]=champs[5]
                insertUser(user)
            elif champs[0] == "enchere":
                enchere={}
                enchere["id_connexion"] = champs[1]
                enchere["id_produits"] = champs[2]
                enchere["prix_base"] = champs[3]
                enchere["prix_final"] = champs[4]
                insertenchere(enchere)
            else :
                print ("fichier incorrect")

def update_enchere(auction, id_connexion, nb):
    req=_requetes["update_enchere"].format(id_connexion, auction, nb)
    executeReq(req)
