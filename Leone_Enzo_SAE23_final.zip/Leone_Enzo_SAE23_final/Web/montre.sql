-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1:3306
-- Généré le : mar. 06 juin 2023 à 17:55
-- Version du serveur : 8.0.31
-- Version de PHP : 8.0.26

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `montre`
--

-- --------------------------------------------------------

--
-- Structure de la table `connexion`
--

DROP TABLE IF EXISTS `connexion`;
CREATE TABLE IF NOT EXISTS `connexion` (
  `mail` varchar(100) NOT NULL,
  `nom` varchar(25) NOT NULL,
  `prenom` varchar(20) NOT NULL,
  `login` varchar(30) NOT NULL,
  `mdp` varchar(20) NOT NULL,
  `connexion` tinyint NOT NULL DEFAULT '0',
  PRIMARY KEY (`mail`)
) ENGINE=InnoDB;

--
-- Déchargement des données de la table `connexion`
--

INSERT INTO `connexion` (`mail`, `nom`, `prenom`, `login`, `mdp`, `connexion`) VALUES
('mailtest', 'nomtest', 'prenomtest', 'logintest', 'mdptest', 1),
('root', 'root', 'root', 'root', 'root', 1);

-- --------------------------------------------------------

--
-- Structure de la table `dedans`
--

DROP TABLE IF EXISTS `dedans`;
CREATE TABLE IF NOT EXISTS `dedans` (
  `id_produit` int NOT NULL,
  `id_lieu` int NOT NULL,
  `prix` float NOT NULL,
  `date` date NOT NULL,
  PRIMARY KEY (`id_produit`,`id_lieu`),
  KEY `proposer_a` (`id_produit`),
  KEY `etre_dans` (`id_lieu`)
) ENGINE=InnoDB;

-- --------------------------------------------------------

--
-- Structure de la table `lieux`
--

DROP TABLE IF EXISTS `lieux`;
CREATE TABLE IF NOT EXISTS `lieux` (
  `id` int NOT NULL AUTO_INCREMENT,
  `url` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB;

-- --------------------------------------------------------

--
-- Structure de la table `prix_enchere`
--

DROP TABLE IF EXISTS `prix_enchere`;
CREATE TABLE IF NOT EXISTS `prix_enchere` (
  `id_connexion` varchar(100) NOT NULL,
  `id_produits` int NOT NULL,
  `prix_base` float NOT NULL,
  `prix_final` float DEFAULT NULL,
  PRIMARY KEY (`id_connexion`,`id_produits`),
  KEY `encherir_sur` (`id_connexion`),
  KEY `acheter_par` (`id_produits`)
) ENGINE=InnoDB;

-- --------------------------------------------------------

--
-- Structure de la table `produits`
--

DROP TABLE IF EXISTS `produits`;
CREATE TABLE IF NOT EXISTS `produits` (
  `id` int NOT NULL AUTO_INCREMENT,
  `nom` varchar(50) NOT NULL,
  `description` text NOT NULL,
  `fabricant` text NOT NULL,
  `mouvement` enum('automatique','manuel','quartz') NOT NULL,
  `enchere` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB;

--
-- Contraintes pour les tables déchargées
--

--
-- Contraintes pour la table `dedans`
--
ALTER TABLE `dedans`
  ADD CONSTRAINT `etre_dans` FOREIGN KEY (`id_lieu`) REFERENCES `lieux` (`id`) ON DELETE CASCADE ON UPDATE RESTRICT,
  ADD CONSTRAINT `proposer_a` FOREIGN KEY (`id_produit`) REFERENCES `produits` (`id`) ON DELETE CASCADE ON UPDATE RESTRICT;

--
-- Contraintes pour la table `prix_enchere`
--
ALTER TABLE `prix_enchere`
  ADD CONSTRAINT `acheter_par` FOREIGN KEY (`id_produits`) REFERENCES `produits` (`id`) ON DELETE CASCADE ON UPDATE RESTRICT,
  ADD CONSTRAINT `encherir_sur` FOREIGN KEY (`id_connexion`) REFERENCES `connexion` (`mail`) ON DELETE CASCADE ON UPDATE RESTRICT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
