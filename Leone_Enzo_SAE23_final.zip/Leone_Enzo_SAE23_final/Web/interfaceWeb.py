import cherrypy, os, os.path
from mako.template import Template
from mako.lookup import TemplateLookup
from FonctionPy import initBase, getPlusBasPrix, insertUser,  getProduits, GetTableProduit, GetTableLieux, GetTablePrix, getTable_User, insertProduit, DeleteProd, loadFromCSVFile, saveToTextFile, insertLieu, insertPrix, updateAuction, filters, reset, getenchere, update_enchere
from configDB import dbConnect

mylookup = TemplateLookup(directories=['res/templates'], input_encoding='utf-8', module_directory='res/tmp/mako_modules')

class InterfaceWebEtudiants(object):    
    ###### Page d'accueil #############
    def __init__(self):
        self.mail = None
        self.nom = None
        self.prenom = None
        self.login = None
        self.mdp =  None
        self.connexion = None
        

    @cherrypy.expose
    def connection(self):
        mytemplate = mylookup.get_template("connexion.html")
        return mytemplate.render(mail =self.mail)
    
    @cherrypy.expose
    def checklogin(self, mail = None, mdp = None):
        user = getTable_User()
        found = False
        for index in range(len(user)):
            if user[index][0] == mail and user[index][4] == mdp:
                self.mail = mail
                self.nom = user[index][1]
                self.prenom = user[index][2]
                self.login = user[index][3]
                self.mdp =  mdp
                self.connexion = user[index][5]
                found = True
                raise cherrypy.HTTPRedirect("index")
        if found == False:
            raise cherrypy.HTTPRedirect("connection")

    @cherrypy.expose
    def index(self):
        produits = filters(None)
        place = GetTableLieux()
        mytemplate = mylookup.get_template("accueil.html")
        return mytemplate.render(produits=produits, place=place, mail =self.mail, login =self.login)

    @cherrypy.expose
    def Deconnexion(self):
        self.mail = None
        self.nom = None
        self.prenom = None
        self.login = None
        self.mdp =  None
        self.connexion = None
        return self.index()


    @cherrypy.expose
    def detail(self, nb):
        mytemplate = mylookup.get_template("detail.html")
        produit = GetTableProduit()
        lieux_prix = getProduits()
        enchere = getenchere()
        return mytemplate.render(nb = int(nb), produit=produit, lieux_prix=lieux_prix, enchere=enchere, mail =self.mail, login=self.login)

    @cherrypy.expose
    def FiltersDone(self, **params):
        produits = filters(params)
        place = GetTableLieux()
        mytemplate = mylookup.get_template("accueil.html")
        return mytemplate.render(produits=produits, place=place, mail =self.mail, login =self.login)

    @cherrypy.expose
    def ResetFilters(self):
        return self.index()

######################## INSERER DES DONNEES ##################################
##### Page d'inserttion #######
    @cherrypy.expose
    def insertPage(self):        
        mytemplate = mylookup.get_template("create_account.html")        
        return mytemplate.render(mail =self.mail)

    @cherrypy.expose
    def insert_Page_data(self):
        produits = GetTableProduit()
        lieux = GetTableLieux()        
        mytemplate = mylookup.get_template("insertdata.html")        
        return mytemplate.render(produits=produits, lieux=lieux, mail =self.mail)

    @cherrypy.expose
    def DeleteProduit(self):
        produit = GetTableProduit()        
        mytemplate = mylookup.get_template("deletedata.html")        
        return mytemplate.render(produit=produit, mail =self.mail)

    @cherrypy.expose
    def UpdateProduit(self):
        produits=GetTableProduit()        
        mytemplate = mylookup.get_template("updatedata.html")        
        return mytemplate.render(produits=produits, mail =self.mail)

############## METHODE D'INSERTION ###############

    @cherrypy.expose
    def insertDone(self, **params):
        insertUser(params)      
        return self.insertPage()
    
    @cherrypy.expose
    def insertProduit(self, **params):
        insertProduit(params)       
        return self.insert_Page_data()

    @cherrypy.expose
    def insertLieu(self, **params):
        insertLieu(params)       
        return self.insert_Page_data()
    
    @cherrypy.expose
    def insertPrice(self, **params):
        insertPrix(params)    
        return self.insert_Page_data()

    @cherrypy.expose
    def deleteDone(self, **params):
        DeleteProd(params)
        return self.DeleteProduit()

    @cherrypy.expose
    def updateDone(self, **params):
        updateAuction(params)
        return self.UpdateProduit()

    


######################### Base ###############################

    @cherrypy.expose
    def Import(self):
        loadFromCSVFile()
        return self.index()

    @cherrypy.expose
    def Export(self):
        saveToTextFile()
        return self.index()

    @cherrypy.expose
    def Reset(self):
        reset()
        return self.index()



####################### Enchère ##############################

    @cherrypy.expose
    def auction(self, **params):
        enchere = getenchere()
        nb = params["id_produit"]
        auction = params["auction"]
        id_connexion = params["id_connexion"]
        for index in range(len(enchere)):
            if enchere[index][1] == int(nb):
                    update_enchere(auction, id_connexion, nb)
                    return self.detail(nb)


if __name__ == '__main__':
    rootPath = os.path.abspath(os.getcwd())
    print(f"la racine du site est :\n\t{rootPath}\n\tcontient : {os.listdir()}")
    initBase()
    cherrypy.quickstart(InterfaceWebEtudiants(), '/', 'config.txt')