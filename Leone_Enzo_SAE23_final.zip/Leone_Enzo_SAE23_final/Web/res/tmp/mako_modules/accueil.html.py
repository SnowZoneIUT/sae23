# -*- coding:utf-8 -*-
from mako import runtime, filters, cache
UNDEFINED = runtime.UNDEFINED
STOP_RENDERING = runtime.STOP_RENDERING
__M_dict_builtin = dict
__M_locals_builtin = locals
_magic_number = 10
_modified_time = 1686084736.0583806
_enable_loop = True
_template_filename = 'res/templates/accueil.html'
_template_uri = 'accueil.html'
_source_encoding = 'utf-8'
_exports = []


def _mako_get_namespace(context, name):
    try:
        return context.namespaces[(__name__, name)]
    except KeyError:
        _mako_generate_namespaces(context)
        return context.namespaces[(__name__, name)]
def _mako_generate_namespaces(context):
    pass
def _mako_inherit(template, context):
    _mako_generate_namespaces(context)
    return runtime._inherit_from(context, 'template.html', _template_uri)
def render_body(context,**pageargs):
    __M_caller = context.caller_stack._push_frame()
    try:
        __M_locals = __M_dict_builtin(pageargs=pageargs)
        mail = context.get('mail', UNDEFINED)
        produits = context.get('produits', UNDEFINED)
        str = context.get('str', UNDEFINED)
        len = context.get('len', UNDEFINED)
        range = context.get('range', UNDEFINED)
        __M_writer = context.writer()
        __M_writer('\r\n\r\n<body>\r\n\r\n    <!-- Navbar Start -->\r\n    <div class="container-fluid bg-dark mb-30">\r\n        <div class="row px-xl-5">\r\n            <div class="col-lg-3 d-none d-lg-block">\r\n                <a class="btn d-flex align-items-center justify-content-between bg-primary w-100" data-toggle="collapse" href="#navbar-vertical" style="height: 65px; padding: 0 30px;">\r\n                    <h6 class="text-dark m-0">WatchAuction : ')
        __M_writer(str(mail))
        __M_writer('</h6>\r\n                </a>\r\n            </div>\r\n            <div class="col-lg-9">\r\n                <nav class="navbar navbar-expand-lg bg-dark navbar-dark py-3 py-lg-0 px-0">\r\n                    <a href="" class="text-decoration-none d-block d-lg-none">\r\n                        <span class="h1 text-uppercase text-dark bg-light px-2">Watch</span>\r\n                        <span class="h1 text-uppercase text-light bg-primary px-2 ml-n1">Shop</span>\r\n                    </a>\r\n                    <button type="button" class="navbar-toggler" data-toggle="collapse" data-target="#navbarCollapse">\r\n                        <span class="navbar-toggler-icon"></span>\r\n                    </button>\r\n                    <div class="collapse navbar-collapse justify-content-between" id="navbarCollapse">\r\n                        <div class="navbar-nav mr-auto py-0">\r\n                            <a href="/" class="nav-item nav-link active">Shop</a>\r\n')
        if mail == None:
            __M_writer('                                <div class="nav-item dropdown">\r\n                                    <a href="#" class="nav-link dropdown-toggle" data-toggle="dropdown">Mon compte <i class="fa fa-angle-down mt-1"></i></a>\r\n                                    <div class="dropdown-menu bg-primary rounded-0 border-0 m-0">\r\n                                        <a href="connection" class="dropdown-item">Se connecter</a>\r\n                                        <a href="insertPage" class="dropdown-item">Créer un compte</a>\r\n                                    </div>\r\n                                </div>\r\n')
        if mail == "root" :
            __M_writer('                                <div class="nav-item dropdown">\r\n                                    <a href="#" class="nav-link dropdown-toggle" data-toggle="dropdown">Administration <i class="fa fa-angle-down mt-1"></i></a>\r\n                                    <div class="dropdown-menu bg-primary rounded-0 border-0 m-0">\r\n                                        <a href="insert_Page_data" class="dropdown-item">Insérer des données</a>\r\n                                        <a href="DeleteProduit" class="dropdown-item">Supprimer des données</a>\r\n                                        <a href="UpdateProduit" class="dropdown-item">Mettre à jour des données</a>\r\n                                        <form action="Export">\r\n                                            <button type="submit" class="btn btn-primary py-2 px-4">Exporter la base</button>\r\n                                        </form>\r\n                                        <form action="Import">\r\n                                            <button type="submit" class="btn btn-primary py-2 px-4">Importer la base</button>\r\n                                        </form>\r\n                                        <form action="Reset">\r\n                                            <button type="submit" class="btn btn-primary py-2 px-4">Reset la base</button>\r\n                                        </form>\r\n                                    </div>\r\n                                </div>\r\n')
        if mail != None :
            __M_writer('                                <div class="nav-item dropdown">\r\n                                    <a href="#" class="nav-link dropdown-toggle" data-toggle="dropdown">Mon compte <i class="fa fa-angle-down mt-1"></i></a>\r\n                                    <div class="dropdown-menu bg-primary rounded-0 border-0 m-0">\r\n                                        <form action="Deconnexion">\r\n                                            <button type="submit" class="btn btn-primary py-2 px-4">Déconnexion</button>\r\n                                        </form>\r\n                                    </div>\r\n                                </div>\r\n')
        __M_writer('                        </div>\r\n                    </div>\r\n                </nav>\r\n            </div>\r\n        </div>\r\n    </div>\r\n    <!-- Navbar End -->\r\n    <script src="/static/js/filters.js"></script>\r\n    <!-- Shop Start -->\r\n    <div class="container-fluid">\r\n        <div class="row px-xl-5">\r\n            <!-- Shop Sidebar Start -->\r\n            <div class="col-lg-3 col-md-4">\r\n                <form action="FiltersDone">\r\n                    <!-- Price Start -->\r\n                    <h5 class="section-title position-relative text-uppercase mb-3"><span class="bg-secondary pr-3">Filtrer par prix</span></h5>\r\n                    <div class="bg-light p-4 mb-30">\r\n                        <div class="col-md-6 form-group">\r\n                            <label for="prix">Prix</label>\r\n                            <input class="form-control" type="text" placeholder="Saisir le prix du produit à cette url" id="prix" name="prix">\r\n                        </div>\r\n                    </div>\r\n                    <!-- Price End -->\r\n\r\n                    <!-- Type Start -->\r\n                    <h5 class="section-title position-relative text-uppercase mb-3"><span class="bg-secondary pr-3">Filtrer par type</span></h5>\r\n                    <div class="bg-light p-4 mb-30">\r\n                        <div class="custom-control custom-checkbox d-flex align-items-center justify-content-between mb-3">\r\n                            <input type="checkbox" class="custom-control-input" id="type_quartz" name="type_quartz">\r\n                            <label class="custom-control-label" for="type_quartz">Quartz</label>\r\n                        </div>\r\n                        <div class="custom-control custom-checkbox d-flex align-items-center justify-content-between mb-3">\r\n                            <input type="checkbox" class="custom-control-input" id="type_automatique" name="type_automatique">\r\n                            <label class="custom-control-label" for="type_automatique">Automatique</label>\r\n                        </div>\r\n                        <div class="custom-control custom-checkbox d-flex align-items-center justify-content-between mb-3">\r\n                            <input type="checkbox" class="custom-control-input" id="type_manuel" name="type_manuel">\r\n                            <label class="custom-control-label" for="type_manuel">Manuel</label>\r\n                        </div>\r\n                    </div>\r\n                    <!-- Type End -->\r\n\r\n                    <!-- Auction Start -->\r\n                    <h5 class="section-title position-relative text-uppercase mb-3"><span class="bg-secondary pr-3">Filtrer par enchère</span></h5>\r\n                    <div class="bg-light p-4 mb-30">\r\n                        <div class="custom-control custom-checkbox d-flex align-items-center justify-content-between mb-3">\r\n                            <input type="checkbox" class="custom-control-input" id="auction_yes" name="auction_yes" value="1">\r\n                            <label class="custom-control-label" for="auction_yes">Disponible</label>\r\n                        </div>\r\n                        <div class="custom-control custom-checkbox d-flex align-items-center justify-content-between mb-3">\r\n                            <input type="checkbox" class="custom-control-input" id="auction_no" name="auction_no" value="1">\r\n                            <label class="custom-control-label" for="auction_no">Non disponible</label>\r\n                        </div>\r\n                    </div>\r\n                    <!-- Auction End -->\r\n                    <button type="submit" class="btn btn-primary py-2 px-4">Filtrer</button>\r\n                </form>\r\n                <form action="ResetFilters">\r\n                    <button type="submit" class="btn btn-primary py-2 px-4">Réinitialiser les filtres</button>\r\n                </form>\r\n            </div>\r\n            <!-- Shop Sidebar End -->\r\n\r\n\r\n            <!-- Shop Product Start -->\r\n            <script src="/static/js/GoToDetail.js"></script>\r\n            <div class="col-lg-9 col-md-8">\r\n                <div class="row pb-3">\r\n                    <div class="col-12 pb-1">\r\n                        <div class="d-flex align-items-center justify-content-between mb-4">\r\n                        </div>\r\n                    </div>\r\n                    <link href = "/">\r\n')
        for index in range(len(produits)):
            __M_writer('                        <div class="col-lg-4 col-md-6 col-sm-6 pb-1">\r\n                            <div class="product-item bg-light mb-4">\r\n                                <div class="product-img position-relative overflow-hidden">\r\n')
            from os import listdir
            listefichier=listdir("res/img/")
            retour=0
            for elem in listefichier:
                if str(produits[index][1]) in elem:
                    retour = produits[index][1]
            
            
            __M_locals_builtin_stored = __M_locals_builtin()
            __M_locals.update(__M_dict_builtin([(__M_key, __M_locals_builtin_stored[__M_key]) for __M_key in ['listefichier','retour','listdir','elem'] if __M_key in __M_locals_builtin_stored]))
            __M_writer('\r\n                                    <img class="img-fluid w-100" src="/static/img/')
            __M_writer(str(retour))
            __M_writer('.png" alt="">\r\n                                    <!-- <style>\r\n                                        .product-action:hover .loupe {display: block;}\r\n                                    </style> -->\r\n                                    <div class="product-action">\r\n                                        <form action="detail" method="POST">\r\n                                            <select style="display: none;" for="nb" name="nb">\r\n                                                <option value="')
            __M_writer(str(produits[index][0]))
            __M_writer('"></option>\r\n                                            </select>\r\n                                            <button type="submit" class="btn btn-outline-dark btn-square loupe"><i class="fa fa-search"></i></button>\r\n                                        </form>\r\n                                    </div>\r\n                                </div>\r\n                                <div class="text-center py-4">\r\n                                    <a class="h5 text-decoration-none text-truncate" href="">')
            __M_writer(str(produits[index][1]))
            __M_writer('</a>\r\n                                </div>\r\n                            </div>\r\n                        </div>\r\n')
        __M_writer('                </div>\r\n            </div>\r\n            <!-- Shop Product End -->\r\n        </div>\r\n    </div>\r\n    <!-- Shop End -->')
        return ''
    finally:
        context.caller_stack._pop_frame()


"""
__M_BEGIN_METADATA
{"filename": "res/templates/accueil.html", "uri": "accueil.html", "source_encoding": "utf-8", "line_map": {"27": 0, "37": 1, "38": 10, "39": 10, "40": 25, "41": 26, "42": 34, "43": 35, "44": 53, "45": 54, "46": 63, "47": 136, "48": 137, "49": 140, "50": 141, "51": 142, "52": 143, "53": 144, "54": 145, "55": 146, "56": 147, "59": 146, "60": 147, "61": 147, "62": 154, "63": 154, "64": 161, "65": 161, "66": 166, "72": 66}}
__M_END_METADATA
"""
