# -*- coding:utf-8 -*-
from mako import runtime, filters, cache
UNDEFINED = runtime.UNDEFINED
STOP_RENDERING = runtime.STOP_RENDERING
__M_dict_builtin = dict
__M_locals_builtin = locals
_magic_number = 10
_modified_time = 1685897600.685991
_enable_loop = True
_template_filename = 'res/templates/create_account.html'
_template_uri = 'create_account.html'
_source_encoding = 'utf-8'
_exports = []


def _mako_get_namespace(context, name):
    try:
        return context.namespaces[(__name__, name)]
    except KeyError:
        _mako_generate_namespaces(context)
        return context.namespaces[(__name__, name)]
def _mako_generate_namespaces(context):
    pass
def _mako_inherit(template, context):
    _mako_generate_namespaces(context)
    return runtime._inherit_from(context, 'template.html', _template_uri)
def render_body(context,**pageargs):
    __M_caller = context.caller_stack._push_frame()
    try:
        __M_locals = __M_dict_builtin(pageargs=pageargs)
        mail = context.get('mail', UNDEFINED)
        __M_writer = context.writer()
        __M_writer('\r\n<body>\r\n\r\n    <!-- Navbar Start -->\r\n    <div class="container-fluid bg-dark mb-30">\r\n        <div class="row px-xl-5">\r\n            <div class="col-lg-3 d-none d-lg-block">\r\n                <a class="btn d-flex align-items-center justify-content-between bg-primary w-100" data-toggle="collapse" href="#navbar-vertical" style="height: 65px; padding: 0 30px;">\r\n                    <h6 class="text-dark m-0">WatchAuction : ')
        __M_writer(str(mail))
        __M_writer('</h6>\r\n                </a>\r\n            </div>\r\n            <div class="col-lg-9">\r\n                <nav class="navbar navbar-expand-lg bg-dark navbar-dark py-3 py-lg-0 px-0">\r\n                    <a href="" class="text-decoration-none d-block d-lg-none">\r\n                        <span class="h1 text-uppercase text-dark bg-light px-2">Watch</span>\r\n                        <span class="h1 text-uppercase text-light bg-primary px-2 ml-n1">Shop</span>\r\n                    </a>\r\n                    <button type="button" class="navbar-toggler" data-toggle="collapse" data-target="#navbarCollapse">\r\n                        <span class="navbar-toggler-icon"></span>\r\n                    </button>\r\n                    <div class="collapse navbar-collapse justify-content-between" id="navbarCollapse">\r\n                        <div class="navbar-nav mr-auto py-0">\r\n                            <a href="/" class="nav-item nav-link">Shop</a>\r\n')
        if mail == None:
            __M_writer('                                <div class="nav-item dropdown">\r\n                                    <a href="#" class="nav-link dropdown-toggle" data-toggle="dropdown">Mon compte <i class="fa fa-angle-down mt-1"></i></a>\r\n                                    <div class="dropdown-menu bg-primary rounded-0 border-0 m-0">\r\n                                        <a href="connection" class="dropdown-item">Se connecter</a>\r\n                                        <a href="insertPage" class="dropdown-item">Créer un compte</a>\r\n                                    </div>\r\n                                </div>\r\n')
        if mail == "root" :
            __M_writer('                                <div class="nav-item dropdown">\r\n                                    <a href="#" class="nav-link dropdown-toggle" data-toggle="dropdown">Administration <i class="fa fa-angle-down mt-1"></i></a>\r\n                                    <div class="dropdown-menu bg-primary rounded-0 border-0 m-0">\r\n                                        <a href="insert_Page_data" class="dropdown-item">Insérer des données</a>\r\n                                        <a href="DeleteProduit" class="dropdown-item">Supprimer des données</a>\r\n                                        <a href="UpdateProduit" class="dropdown-item">Mettre à jour des données</a>\r\n                                        <form action="Export">\r\n                                            <button type="submit" class="btn btn-primary py-2 px-4">Exporter la base</button>\r\n                                        </form>\r\n                                        <form action="Import">\r\n                                            <button type="submit" class="btn btn-primary py-2 px-4">Importer la base</button>\r\n                                        </form>\r\n                                    </div>\r\n                                </div>\r\n')
        if mail != None :
            __M_writer('                                <div class="nav-item dropdown">\r\n                                    <a href="#" class="nav-link dropdown-toggle" data-toggle="dropdown">Mon compte <i class="fa fa-angle-down mt-1"></i></a>\r\n                                    <div class="dropdown-menu bg-primary rounded-0 border-0 m-0">\r\n                                        <form action="Deconnexion">\r\n                                            <button type="submit" class="btn btn-primary py-2 px-4">Déconnexion</button>\r\n                                        </form>\r\n                                    </div>\r\n                                </div>\r\n')
        __M_writer('                        </div>\r\n                    </div>\r\n                </nav>\r\n            </div>\r\n        </div>\r\n    </div>\r\n    <!-- Navbar End -->\r\n\r\n    <!-- Checkout Start -->\r\n    <div class="container-fluid">\r\n        <div class="row px-xl-5">\r\n            <div class="col-lg-8">\r\n                <h5 class="section-title position-relative text-uppercase mb-3"><span class="bg-secondary pr-3">Créer un compte : </span></h5>\r\n                <div class="bg-light p-30 mb-5">\r\n                    <div class="row">\r\n                        <form action="insertDone">\r\n                            <div class="col-md-6 form-group">\r\n                                <label for="prenom">Prénom</label>\r\n                                <input class="form-control" type="text" placeholder="John" id="prenom" name="prenom" required>\r\n                            </div>\r\n                            <div class="col-md-6 form-group">\r\n                                <label for="nom">Nom</label>\r\n                                <input class="form-control" type="text" placeholder="Doe" id="nom" name="nom" required>\r\n                            </div>\r\n                            <div class="col-md-6 form-group">\r\n                                <label for="mail">E-mail</label>\r\n                                <input class="form-control" type="text" placeholder="example@email.com" id="mail" name="mail" required>\r\n                            </div>\r\n                            <div class="col-md-6 form-group">\r\n                                <label for="login">Login</label>\r\n                                <input class="form-control" type="text" placeholder="Login" id="login" name="login" required>\r\n                            </div>\r\n                            <div class="col-md-6 form-group">\r\n                                <label for="mdp">Mot de passe</label>\r\n                                <input class="form-control" type="text" placeholder="motDepassepassecu" id="mdp" name="mdp" required>\r\n                            </div>\r\n                            <button type="submit" class="btn btn-primary py-2 px-4">Créer</button>\r\n                        </form>\r\n                    </div>\r\n                </div>\r\n            </div>\r\n        </div>\r\n    </div>\r\n    <!-- Checkout End -->')
        return ''
    finally:
        context.caller_stack._pop_frame()


"""
__M_BEGIN_METADATA
{"filename": "res/templates/create_account.html", "uri": "create_account.html", "source_encoding": "utf-8", "line_map": {"27": 0, "33": 1, "34": 9, "35": 9, "36": 24, "37": 25, "38": 33, "39": 34, "40": 49, "41": 50, "42": 59, "48": 42}}
__M_END_METADATA
"""
