bibliotèque python utilisée : os, pymysql, csv

Le fichier de configuration contient les différentes informations pour pouvoir se connecter, il faudra sûremement modifier ce fichier
Il suffit de lancer l'interfaceWeb.py pour pouvoir lancer l'appliation.
Puis il faut se connecter avec l'utilisateur root dans la navbar : --> mon compte --> connexion ( mail = root, mdp = root)
Ensuite il faut importer la base : navbar --> administration --> Importer.
Et voila


changement :

- modif de la table produit : rajout de la colonne enchère 
- rajout de la table connexion et prix_enchere
- rajout des routines etc


Ce que je n'ai pas fait : - les filtres selon les fabricants et les lieux
			  - Un timer pour arrêter automatiquement l'enchère. ( c'est l'admin qui se devra se charger d'arrêter la vente )
			  - Vérification du type de la date pour l'inserttion prix_enchere

